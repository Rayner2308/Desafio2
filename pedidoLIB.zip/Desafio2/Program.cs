﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using pedidoLIB;
namespace Desafio2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PEDIDO PrimerPedido = new PEDIDO();
           
            while (!PrimerPedido.PedidoProcesado()) ;
            Console.WriteLine("\n\nTodas las operaciones se han procesado. El pedido se ha procesado exitosamente.");
            
            Environment.Exit(0);
        }
    }
}
