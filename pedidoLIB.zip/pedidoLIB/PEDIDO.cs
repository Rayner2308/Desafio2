﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace pedidoLIB
{
    public class PEDIDO
    {
        // Atributos Thread
        public Thread T1;// T1: Validacion
        public Thread T2;// T2: Cobro
        public Thread T3;// T3: Actualización del Inventario
        public Thread T4;// T4: Notificación al cliente
        public int pasos;// Incrementa para cada operación (hilo) culminado.
        // Clases
        public PEDIDO()
        {
            // Constructor. Creamos un Hilo de las cuatro funciones de la clase.
            pasos = 0;
            T1 = new Thread(validacion);
            T2 = new Thread(cobro);
            T3 = new Thread(ActualizarInventario);
            T4 = new Thread(Notificar);
            Console.WriteLine("Procesando pedido de E-commerce:\n\n");
            // Iniciamos el Hilo
            T1.Start();
            T2.Start();
            T3.Start();
            T4.Start();
        }
        public void validacion()
        {
            // Inicia Hilo aqui
            Console.WriteLine("Iniciando validación del pedido...");
            // Detener Hilo por 5 segundos
            Thread.Sleep(5000);
            Console.WriteLine("Validacion completada: Todos los articulos están disponibles.");
            // incrementamos variable pasos para indicar que terminó la validación
            pasos++;
        }
        public void cobro()
        {
            // Iniciar Hilo aqui
            Console.WriteLine("Iniciando cobro de pago...");
            // Detener Hilo por 12 segundos
            Thread.Sleep(12000);
            Console.WriteLine("Pago procesado exitosamente.");
            // incrementamos variable pasos para indicar que terminó el cobro
            pasos++;
        }
        public void ActualizarInventario()
        {
            // Iniciar Hilo aqui
            Console.WriteLine("Actualizando inventario...");
            // Detener Hilo por 2 segundos
            Thread.Sleep(2000);
            Console.WriteLine("Inventario Actualizado correctamente.");
            // incrementamos variable pasos para indicar que terminó de actualizar inventario
            pasos++;
        }
        public void Notificar()
        {
            // Iniciar Hilo aqui
            Console.WriteLine("Enviando confirmación de pedido al cliente...");
            // Detener Hilo por 0.5 segundos
            Thread.Sleep(500);
            Console.WriteLine("Notificación enviada exitosamente.");
            // incrementamos variable pasos para indicar que terminó de notificar al correo
            pasos++;
        }

        public bool PedidoProcesado()
        {
            return (pasos == 4);
        }
    }
}
